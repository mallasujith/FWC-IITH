
//function to calculate Mid points
void midpoint(double x1, double y1, double x2, double y2, double *midpoint_x, double *midpoint_y) {
    *midpoint_x = (x1 + x2) / 2.0;
    *midpoint_y = (y1 + y2) / 2.0;
}

// Function to calculate the slope of a line
double calculateSlope(double x1, double y1, double x2, double y2) {
    return (y2 - y1) / (x2 - x1);
}

// Function to calculate the perpendicular bisector of a side
void calculatePerpendicularBisector(double x1, double y1, double x2, double y2,
                                     double *slope, double *midpoint_x, double *midpoint_y) {
    *slope = -1 / calculateSlope(x1, y1, x2, y2);
    midpoint(x1, y1, x2, y2, midpoint_x, midpoint_y);
}

// Function to find distance between two vertices
double distance(int x1, int y1, int x2, int y2) {
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}

//Function to find angle between sides of a triangle
double calculateAngle(double a, double b, double c) {
    return acos((b * b + c * c - a * a) / (2 * b * c));
}

