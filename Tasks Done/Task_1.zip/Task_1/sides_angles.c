#include <stdio.h>
#include <math.h>

// Function to calculate the distance between two points
double distance(int x1, int y1, int x2, int y2) {
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}

// Function to calculate the angle opposite to the side using the law of cosines
double calculateAngle(double a, double b, double c) {
    return acos((b*b + c*c - a*a) / (2*b*c));
}

int main() {
    // Triangle vertices
    int x1, y1, x2, y2, x3, y3;

    // Input vertices
    printf("Enter coordinates of vertex A (x1 y1): ");
    scanf("%d %d", &x1, &y1);

    printf("Enter coordinates of vertex B (x2 y2): ");
    scanf("%d %d", &x2, &y2);

    printf("Enter coordinates of vertex C (x3 y3): ");
    scanf("%d %d", &x3, &y3);

    // Calculate sides
    double sideAB = distance(x1, y1, x2, y2);
    double sideBC = distance(x2, y2, x3, y3);
    double sideCA = distance(x3, y3, x1, y1);

    // Calculate angles in radians
    double angleA = calculateAngle(sideBC, sideCA, sideAB);
    double angleB = calculateAngle(sideCA, sideAB, sideBC);
    double angleC = calculateAngle(sideAB, sideBC, sideCA);

    // Convert angles to degrees
    angleA = angleA * 180 / M_PI;
    angleB = angleB * 180 / M_PI;
    angleC = angleC * 180 / M_PI;

    // Display results
    printf("Side AB: %.2f\n", sideAB);
    printf("Side BC: %.2f\n", sideBC);
    printf("Side CA: %.2f\n", sideCA);

    printf("Angle A: %.2f degrees\n", angleA);
    printf("Angle B: %.2f degrees\n", angleB);
    printf("Angle C: %.2f degrees\n", angleC);

    return 0;
}

