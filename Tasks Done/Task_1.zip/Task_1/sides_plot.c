#include <stdio.h>

int main() {
    // Open a file for writing
    FILE *dataFile = fopen("output.dat", "w");

    if (!dataFile) {
        printf("Error opening data file!\n");
        return 1;
    }

    // Triangle vertices with new coordinates
    fprintf(dataFile, "%d %d\n", 1, -1);     // A
    fprintf(dataFile, "%d %d\n", -4, 6);     // B
    fprintf(dataFile, "%d %d\n", -3, -5);    // C
    fprintf(dataFile, "%d %d\n", 1, -1);     // Close the loop

    // Connect vertices in the order AB-BC-CA
    fprintf(dataFile, "%d %d\n", -4, 6);     // B
    fprintf(dataFile, "%d %d\n", -3, -5);    // C

    fprintf(dataFile, "%d %d\n", 1, -1);     // A
    fprintf(dataFile, "%d %d\n", -4, 6);     // B

    // Close the file
    fclose(dataFile);

    // Use Gnuplot to plot the data file
    FILE *gnuplotPipe = popen("gnuplot -persist", "w");

    if (gnuplotPipe) {
        // Send commands to Gnuplot
        fprintf(gnuplotPipe, "set xrange [-8:6]\n"); // Set x-axis range
        fprintf(gnuplotPipe, "set yrange [-6:6]\n"); // Set y-axis range
        fprintf(gnuplotPipe, "set grid\n");          // Enable grid lines

        // Labels for starting points
        fprintf(gnuplotPipe, "set label 'A (1,-1)' at 1.25,-1\n");
        fprintf(gnuplotPipe, "set label 'B (-4,6)' at -4.25,6.25\n");
        fprintf(gnuplotPipe, "set label 'C (-3,-5)' at -3.25,-5.25\n");

        // Plot commands with separate titles for AB, BC, and CA
        fprintf(gnuplotPipe, "plot 'output.dat' using 1:2 every 4::0 with linespoints pointtype 7 title 'AB', '' every 4::1 with linespoints pointtype 7 title 'BC', '' every 4::2 with linespoints pointtype 7 title 'CA'\n");
        fflush(gnuplotPipe);

        printf("Press enter to exit...");
        getchar();

        // Close the Gnuplot pipe
        fprintf(gnuplotPipe, "exit\n");
        pclose(gnuplotPipe);
    } else {
        printf("Gnuplot not found. Please install Gnuplot to use this program.\n");
    }

    return 0;
}
